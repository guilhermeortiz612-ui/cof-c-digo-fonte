/*
vid_common.c - common vid component
Copyright (C) 2018 a1batross, Uncle Mike

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#include "common.h"
#include "client.h"
#include "mod_local.h"
#include "input.h"
#include "vid_common.h"
#include "platform/platform.h"

static CVAR_DEFINE_AUTO( vid_mode, "0", FCVAR_RENDERINFO, "current video mode index (used only for storage)" );
static CVAR_DEFINE_AUTO( vid_rotate, DEFAULT_VID_ROTATE, FCVAR_RENDERINFO|FCVAR_VIDRESTART, "screen rotation (0-3)" );

CVAR_DEFINE_AUTO( vid_maximized, "0", FCVAR_RENDERINFO, "window maximized state, read-only" );
CVAR_DEFINE( vid_fullscreen, "fullscreen", DEFAULT_FULLSCREEN, FCVAR_RENDERINFO|FCVAR_VIDRESTART, "fullscreen state (0 windowed, 1 fullscreen, 2 borderless)" );
CVAR_DEFINE( window_width, "width", "0", FCVAR_RENDERINFO|FCVAR_VIDRESTART, "screen width" );
CVAR_DEFINE( window_height, "height", "0", FCVAR_RENDERINFO|FCVAR_VIDRESTART, "screen height" );
CVAR_DEFINE( vid_width, "vid_width", "0", FCVAR_READ_ONLY, "actual window viewport size" );
CVAR_DEFINE( vid_height, "vid_height", "0", FCVAR_READ_ONLY, "actual window viewport size" );
static CVAR_DEFINE( vid_window_insets, "_window_insets", "", FCVAR_PRIVILEGED, "override window safe area insets for testing: left top right bottom, in pixels" );

glwstate_t	glw_state;

/*
=================
R_SaveVideoMode
=================
*/
void R_SaveVideoMode( int w, int h, int render_w, int render_h, qboolean maximized )
{
	string temp;

	if( !w || !h || !render_w || !render_h )
	{
		host.renderinfo_changed = false;
		return;
	}

	host.window_center_x = w / 2;
	host.window_center_y = h / 2;

	Q_snprintf( temp, sizeof( temp ), "%d", w );
	Cvar_DirectSet( &window_width, temp );

	Q_snprintf( temp, sizeof( temp ), "%d", h );
	Cvar_DirectSet( &window_height, temp );

	Q_snprintf( temp, sizeof( temp ), "%d", render_w );
	Cvar_FullSet( "vid_width", temp, vid_width.flags );

	Q_snprintf( temp, sizeof( temp ), "%d", render_h );
	Cvar_FullSet( "vid_height", temp, vid_width.flags  );

	Cvar_DirectSet( &vid_maximized, maximized ? "1" : "0" );
	
	// immediately drop changed state or we may trigger
	// video subsystem to reapply settings
	host.renderinfo_changed = false;

	refState.scale_x = (float)render_w / w;
	refState.scale_y = (float)render_h / h;

	if( refState.width == render_w && refState.height == render_h )
		return;

	refState.width = render_w;
	refState.height = render_h;

	// check for 4:3 or 5:4
	refState.wideScreen = render_w * 3 != render_h * 4 && render_w * 4 != render_h * 5;

	SCR_VidInit(); // tell client.dll that vid_mode has changed
}

/*
=================
VID_GetModeString
=================
*/
const char *VID_GetModeString( int vid_mode )
{
	if( vid_mode < 0 || vid_mode >= R_MaxVideoModes() )
		return NULL;

	vidmode_t *vidmode = R_GetVideoMode( vid_mode );
	if( !vidmode )
		return NULL;

	return vidmode->desc;
}

/*
==================
VID_CheckChanges

check vid modes and fullscreen
==================
*/
void VID_CheckChanges( void )
{
	if( FBitSet( cl_allow_levelshots.flags, FCVAR_CHANGED ))
	{
		//GL_FreeTexture( cls.loadingBar );
		SCR_RegisterTextures(); // reload 'lambda' image
		ClearBits( cl_allow_levelshots.flags, FCVAR_CHANGED );
	}

	if( host.renderinfo_changed )
	{
		if( VID_SetMode( ))
		{
			SCR_VidInit(); // tell the client.dll what vid_mode has changed
		}
		else
		{
			Sys_Error( "Can't re-initialize video subsystem\n" );
		}
		host.renderinfo_changed = false;
	}
}

/*
===============
VID_SetDisplayTransform

notify ref dll about screen transformations
===============
*/
void VID_SetDisplayTransform( int *render_w, int *render_h )
{
	uint rotate = vid_rotate.value;
	int offset_x = 0, offset_y = 0;

	if( rotate < REF_ROTATE_NONE || rotate > REF_ROTATE_CCW )
		rotate = REF_ROTATE_NONE;

#if XASH_SAILFISH
	// only landscape and inverted landscape make sense on a phone
	if( rotate != REF_ROTATE_CW && rotate != REF_ROTATE_CCW )
		rotate = REF_ROTATE_CW;

	// the compositor rotates the window itself, it has to know the orientation to put the keyboard right anyway
	Sailfish_SetOrientation( rotate );
	Sailfish_GetDisplayOffset( &offset_x, &offset_y );
	rotate = REF_ROTATE_NONE;
#endif // XASH_SAILFISH

	if( ref.dllFuncs.R_SetDisplayTransform( rotate, offset_x, offset_y, 1.0f, 1.0f ))
	{
		if( rotate & 1 )
		{
			int swap = *render_w;

			*render_w = *render_h;
			*render_h = swap;
		}

		ref.rotation = rotate;
	}
	else
	{
		Con_Printf( S_WARN "failed to setup screen transform\n" );

		ref.rotation = REF_ROTATE_NONE;
	}
}

static void VID_Mode_f( void )
{
	int w, h;

	switch( Cmd_Argc() )
	{
	case 2:
	{
		vidmode_t *vidmode = R_GetVideoMode( Q_atoi( Cmd_Argv( 1 )) );
		if( !vidmode )
		{
			Con_Printf( S_ERROR "unable to set mode, backend returned null\n" );
			return;
		}

		w = vidmode->width;
		h = vidmode->height;
		break;
	}
	case 3:
	{
		w = Q_atoi( Cmd_Argv( 1 ));
		h = Q_atoi( Cmd_Argv( 2 ));
		break;
	}
	default:
		Msg( S_USAGE "vid_mode <modenum>|<width height>\n" );
		return;
	}

	R_ChangeDisplaySettings( w, h, bound( 0, vid_fullscreen.value, WINDOW_MODE_COUNT - 1 ));
}

static void VID_ValidateWindowInsets( float *insets )
{
	for( int i = 0; i < 4; i++ )
	{
		if( IS_NAN( insets[i] ) || insets[i] < 0 || insets[i] >= 1 )
		{
			memset( insets, 0, sizeof( float ) * 4 );
			return;
		}
	}
	if( insets[0] + insets[2] >= 1 || insets[1] + insets[3] >= 1 )
		memset( insets, 0, sizeof( float ) * 4 );
}

/*
==================
VID_UpdateWindowInsets

refresh cached window safe area insets, called once per frame
==================
*/
void VID_UpdateWindowInsets( void )
{
	if( FBitSet( vid_window_insets.flags, FCVAR_CHANGED ) && !COM_StringEmpty( vid_window_insets.string ) && refState.width > 0 && refState.height > 0 )
	{
		Q_atov( host.window_insets, vid_window_insets.string, 4 );
		host.window_insets[0] /= refState.width;
		host.window_insets[1] /= refState.height;
		host.window_insets[2] /= refState.width;
		host.window_insets[3] /= refState.height;
	}
	else
	{
		Platform_GetWindowInsets( host.hWnd, host.window_insets );
	}

	VID_ValidateWindowInsets( host.window_insets );
}

void VID_Init( void )
{
	// system screen width and height (don't suppose for change from console at all)
	Cvar_RegisterVariable( &window_width );
	Cvar_RegisterVariable( &window_height );

	Cvar_RegisterVariable( &vid_mode );
	Cvar_RegisterVariable( &vid_rotate );
	Cvar_RegisterVariable( &vid_fullscreen );
	Cvar_RegisterVariable( &vid_maximized );
	Cvar_RegisterVariable( &vid_width );
	Cvar_RegisterVariable( &vid_height );
	Cvar_RegisterVariable( &vid_window_insets );
	Cvar_Get( "_window_xpos", "-1", FCVAR_RENDERINFO, "deprecated cvar" );
	Cvar_Get( "_window_ypos", "-1", FCVAR_RENDERINFO, "deprecated cvar" );

	// a1ba: planned to be named vid_mode for compability
	// but supported mode list is filled by backends, so numbers are not portable any more
	Cmd_AddRestrictedCommand( "vid_setmode", VID_Mode_f, "display video mode" );
	Cmd_AddCommand( "vid_info", VID_Info_f, "show vid component info" );

	V_Init(); // init gamma
	R_Init(); // init renderer
}

#if XASH_ENGINE_TESTS
#include "tests.h"

void Test_RunWindowInsets( void )
{
	float insets[4] = { 0.05f, 0, 0.05f, 0.02f };

	VID_ValidateWindowInsets( insets );
	TASSERT( insets[0] == 0.05f && insets[3] == 0.02f );
	insets[0] = -1;
	VID_ValidateWindowInsets( insets );
	TASSERT( insets[0] == 0 && insets[3] == 0 );
	insets[0] = insets[2] = 0.5f;
	VID_ValidateWindowInsets( insets );
	TASSERT( insets[0] == 0 && insets[2] == 0 );
	insets[1] = UintAsFloat( 0x7fc00000 );
	VID_ValidateWindowInsets( insets );
	TASSERT( insets[1] == 0 );
}
#endif // XASH_ENGINE_TESTS
